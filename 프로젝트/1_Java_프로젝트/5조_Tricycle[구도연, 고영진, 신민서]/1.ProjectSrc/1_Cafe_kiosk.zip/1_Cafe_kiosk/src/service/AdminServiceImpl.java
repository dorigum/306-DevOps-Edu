package service;

import exception.BusinessRuleException;
import exception.NotFoundException;
import exception.RepositoryException;
import exception.ValidationException;
import model.*;
import repository.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AdminServiceImpl implements AdminService {
	private final MenuRepository menuRepository;
	private final MemberRepository memberRepository;
	private final CategoryRepository categoryRepository;
	private final OrderRepository orderRepository;
	private final OptionGroupRepository optionGroupRepository;
	private final MenuOptionRepository menuOptionRepository;

	public AdminServiceImpl() {
		this(new MenuRepositoryImpl(), new MemberRepositoryImpl(), new CategoryRepositoryImpl(),
				new OrderRepositoryImpl(), new OptionGroupRepositoryImpl(), new MenuOptionRepositoryImpl());
	}

	public AdminServiceImpl(MenuRepository menuRepository, MemberRepository memberRepository,
			CategoryRepository categoryRepository, OrderRepository orderRepository,
			OptionGroupRepository optionGroupRepository, MenuOptionRepository menuOptionRepository) {
		this.menuRepository = menuRepository;
		this.memberRepository = memberRepository;
		this.categoryRepository = categoryRepository;
		this.orderRepository = orderRepository;
		this.optionGroupRepository = optionGroupRepository;
		this.menuOptionRepository = menuOptionRepository;
	}

	// --- 메뉴 관리 ---
	public void registerMenu(int categoryId, String name, int price, String description) {
		if (name == null || name.trim().isEmpty()) {
			throw new ValidationException("메뉴명은 비어 있을 수 없습니다.");
		}
		if (price <= 0) {
			throw new ValidationException("가격은 1원 이상이어야 합니다.");
		}
		Category category = categoryRepository.getCategoryById(categoryId);
		if (category == null) {
			throw new NotFoundException("존재하지 않는 카테고리 ID입니다.");
		}

		String trimmedName = name.trim();
		Menu menu = new Menu(categoryId, trimmedName, price, description == null ? "" : description.trim());

		// 1. 메뉴 기본 정보 등록
		if (!menuRepository.addMenu(menu)) {
			throw new BusinessRuleException("메뉴 등록에 실패했습니다.");
		}

		// 2. [템플릿 방식] 카테고리에 설정된 기본 옵션 그룹들을 메뉴에 자동 매핑
		// 방금 등록된 메뉴의 ID 조회 (가장 최근 등록된 동일 이름의 메뉴)
		List<Menu> allMenus = menuRepository.getAllMenus();
		Menu registeredMenu = allMenus.stream()
				.filter(m -> m.getMenuName().equals(trimmedName))
				.sorted((m1, m2) -> Long.compare(m2.getMenuId(), m1.getMenuId()))
				.findFirst()
				.orElse(null);

		if (registeredMenu != null && category.getOptionGroups() != null) {
			int order = 1;
			for (OptionGroup og : category.getOptionGroups()) {
				menuRepository.addOptionGroupToMenu(registeredMenu.getMenuId(), og.getGroupId(), order++);
			}
		}
	}

	public List<Menu> getMenuList() {
		return menuRepository.getAllMenus();
	}

	@Override
	public void updateMenu(long menuId, int categoryId, String name, int price, String description, boolean isAvailable) {
		if (name == null || name.trim().isEmpty()) {
			throw new ValidationException("메뉴명은 비어 있을 수 없습니다.");
		}
		if (price <= 0) {
			throw new ValidationException("가격은 1원 이상이어야 합니다.");
		}
		
		Menu existingMenu = menuRepository.findById(menuId);
		if (existingMenu == null) {
			throw new NotFoundException("수정할 메뉴가 존재하지 않습니다.");
		}

		Category category = categoryRepository.getCategoryById(categoryId);
		if (category == null) {
			throw new NotFoundException("존재하지 않는 카테고리 ID입니다.");
		}

		Menu updatedMenu = new Menu(menuId, categoryId, category.getCategoryName(), name.trim(), price, 
				description == null ? "" : description.trim(), isAvailable, existingMenu.getCreatedAt());

		if (!menuRepository.updateMenu(updatedMenu)) {
			throw new BusinessRuleException("메뉴 정보 수정에 실패했습니다.");
		}
	}

	public void deleteMenu(long id) {
		if (!menuRepository.deleteMenu(id)) {
			throw new NotFoundException("삭제할 메뉴가 없습니다.");
		}
	}

	@Override
	public void addOptionGroupToMenu(long menuId, long groupId, int displayOrder) {
		Menu menu = menuRepository.findById(menuId);
		if (menu == null) throw new NotFoundException("메뉴를 찾을 수 없습니다.");
		
		OptionGroup group = optionGroupRepository.findById(groupId);
		if (group == null) throw new NotFoundException("옵션 그룹을 찾을 수 없습니다.");

		menuRepository.addOptionGroupToMenu(menuId, groupId, displayOrder);
	}

	@Override
	public void removeOptionGroupFromMenu(long menuId, long groupId) {
		Menu menu = menuRepository.findById(menuId);
		if (menu == null) throw new NotFoundException("메뉴를 찾을 수 없습니다.");
		
		menuRepository.removeOptionGroupFromMenu(menuId, groupId);
	}

	// --- 카테고리 관리 ---
	public void addCategory(String name) {
		if (name == null || name.trim().isEmpty()) {
			throw new ValidationException("카테고리명은 비어 있을 수 없습니다.");
		}
		if (!categoryRepository.addCategory(name.trim())) {
			throw new BusinessRuleException("카테고리 등록에 실패했습니다.");
		}
	}

	public List<Category> getCategoryList() {
		return categoryRepository.getAllCategories();
	}

	public void deleteCategory(int id) {
		if (!categoryRepository.deleteCategory(id)) {
			throw new NotFoundException("삭제할 카테고리가 없습니다.");
		}
	}

	@Override
	public Category getCategoryById(int id) {
		return categoryRepository.getCategoryById(id);
	}

	// --- 옵션 그룹 관리 ---
	@Override
	public List<OptionGroup> getOptionGroupList() {
		return optionGroupRepository.findAll();
	}

	@Override
	public void addOptionGroup(String name) {
		if (name == null || name.trim().isEmpty()) {
			throw new ValidationException("옵션 그룹명은 비어 있을 수 없습니다.");
		}
		
		String trimmedName = name.trim();
		// 중복 체크 로직 추가
		List<OptionGroup> existingGroups = optionGroupRepository.findAll();
		boolean isDuplicate = existingGroups.stream()
				.anyMatch(g -> g.getGroupName().equalsIgnoreCase(trimmedName));
		
		if (isDuplicate) {
			throw new BusinessRuleException("이미 존재하는 옵션 그룹명입니다: " + trimmedName);
		}
		
		optionGroupRepository.save(new OptionGroup(trimmedName));
	}

	@Override
	public void deleteOptionGroup(long groupId) {
		optionGroupRepository.delete(groupId);
	}

	// --- 메뉴 옵션 관리 ---
	@Override
	public List<MenuOption> getMenuOptionsByGroup(long groupId) {
		return menuOptionRepository.findByGroupId(groupId);
	}

	@Override
	public void addMenuOption(long groupId, String name, int extraPrice, int displayOrder) {
		if (name == null || name.trim().isEmpty()) {
			throw new ValidationException("옵션명은 비어 있을 수 없습니다.");
		}
		MenuOption option = new MenuOption(groupId, name.trim(), extraPrice, displayOrder);
		menuOptionRepository.save(option);
	}

	@Override
	public void updateMenuOption(long optionId, String name, int extraPrice, int displayOrder) {
		MenuOption option = menuOptionRepository.findById(optionId);
		if (option == null) {
			throw new NotFoundException("수정할 옵션이 존재하지 않습니다.");
		}
		option.setOptionName(name);
		option.setExtraPrice(extraPrice);
		option.setDisplayOrder(displayOrder);
		menuOptionRepository.update(option);
	}

	@Override
	public void deleteMenuOption(long optionId) {
		menuOptionRepository.delete(optionId);
	}

	// --- 회원 관리 ---
	public List<Member> getMemberList() {
		return memberRepository.getAllMembers();
	}

	public void deleteMember(long id) {
		Member member = memberRepository.getMemberById(id);
		if (member == null) {
			throw new NotFoundException("삭제할 회원이 없습니다.");
		}

		if ("ADMIN".equalsIgnoreCase(member.getRole())) {
			throw new BusinessRuleException("관리자 계정은 직접 삭제할 수 없습니다. 삭제하려면 먼저 일반 회원으로 등급을 변경해야 합니다.");
		}

		if (!memberRepository.deleteMember(id)) {
			throw new RepositoryException("회원 삭제 중 알 수 없는 오류가 발생했습니다.");
		}
	}

	@Override
	public void updateMemberRole(long id, String newRole) {
		if (newRole == null || (!newRole.equalsIgnoreCase("ADMIN") && !newRole.equalsIgnoreCase("USER"))) {
			throw new ValidationException("올바른 등급(ADMIN, USER)을 입력해 주세요.");
		}

		Member targetMember = memberRepository.getMemberById(id);
		if (targetMember == null) {
			throw new NotFoundException("해당 회원을 찾을 수 없습니다.");
		}

		// 1인 관리자 제한 체크: 새 등급을 ADMIN으로 하려는 경우
		if (newRole.equalsIgnoreCase("ADMIN")) {
			List<Member> allMembers = memberRepository.getAllMembers();
			boolean adminExists = allMembers.stream().anyMatch(m -> "ADMIN".equalsIgnoreCase(m.getRole()) && m.getMemberId() != id);
			
			if (adminExists) {
				throw new BusinessRuleException("이미 관리자가 존재합니다. 관리자는 1명만 설정할 수 있습니다.");
			}
		}

		if (!memberRepository.updateRole(id, newRole)) {
			throw new RepositoryException("등급 변경 중 오류가 발생했습니다.");
		}
	}

	@Override
	public void updateMemberPoint(long id, int amount, String reason) {
		if (amount == 0) {
			throw new ValidationException("수정할 포인트 금액은 0원일 수 없습니다.");
		}
		
		if (reason == null || reason.trim().isEmpty()) {
			throw new ValidationException("포인트 수정 사유를 반드시 입력해 주세요.");
		}

		Member member = memberRepository.getMemberById(id);
		if (member == null) {
			throw new NotFoundException("포인트를 수정할 회원을 찾을 수 없습니다.");
		}

		if ("ADMIN".equalsIgnoreCase(member.getRole())) {
			throw new BusinessRuleException("관리자 등급의 회원은 포인트를 수정할 수 없습니다.");
		}

		if (!memberRepository.updatePoint(id, amount)) {
			throw new RepositoryException("포인트 수정 중 알 수 없는 오류가 발생했습니다.");
		}
		
		// [신규] 포인트 변동 히스토리 저장
		memberRepository.savePointHistory(id, amount, reason);
	}

	// --- 주문 관리 ---
	public List<Order> getOrderList() {
		return orderRepository.getAllOrders();
	}

	public void cancelOrder(long orderId) {
		if (!orderRepository.cancelOrder(orderId)) {
			throw new NotFoundException("취소할 수 있는 주문이 없습니다.");
		}
	}

	// --- 통계 기능 ---
	public long getTotalSales() {
		return orderRepository.getTotalSales();
	}

	public Map<String, Long> getSalesByCategory() {
		return orderRepository.getSalesByCategory();
	}

	public List<String> getTopSellingMenus() {
		return orderRepository.getTopSellingMenus();
	}

	public Map<String, Long> getDailySales() {
		return orderRepository.getDailySales();
	}

	public Map<String, Long> getSalesByPeriod(String format) {
		return orderRepository.getSalesByPeriod(format);
	}

	@Override
	public Map<String, Object> getSalesStatsByPeriod(String startDate, String endDate) {
		return orderRepository.getSalesStatsByPeriod(startDate, endDate);
	}

	@Override
	public Map<Integer, Long> getHourlySales() {
		return orderRepository.getHourlySales();
	}

	@Override
	public Map<String, Long> getDayOfWeekSales() {
		Map<String, Long> rawStats = orderRepository.getDayOfWeekSales();
		Map<String, Long> koreanStats = new LinkedHashMap<>();
		
		// 영문 요일을 한글 요일로 매핑하여 정렬된 순서로 저장
		String[][] mapping = {
			{"Monday", "월요일"}, {"Tuesday", "화요일"}, {"Wednesday", "수요일"}, 
			{"Thursday", "목요일"}, {"Friday", "금요일"}, {"Saturday", "토요일"}, {"Sunday", "일요일"}
		};

		for (String[] pair : mapping) {
			koreanStats.put(pair[1], rawStats.getOrDefault(pair[0], 0L));
		}
		return koreanStats;
	}

	@Override
	public List<Map<String, Object>> getTopSpenders(int limit) {
		return orderRepository.getTopSpenders(limit);
	}

	@Override
	public void exportStatisticsToCSV() {
		String dirPath = "resources/cafe_sales_report";
		java.io.File dir = new java.io.File(dirPath);
		if (!dir.exists()) {
			dir.mkdirs(); // 폴더가 없으면 생성
		}

		String fileName = dirPath + "/cafe_sales_report_" + System.currentTimeMillis() + ".csv";
		
		try {
			// 1. 데이터 먼저 수집 (쿼리 도중 오류 발생 시 파일 자체를 생성하지 않음)
			long totalSales = getTotalSales();
			Map<String, Long> categorySales = getSalesByCategory();
			List<String> topMenus = getTopSellingMenus();
			Map<String, Long> dailySales = getDailySales();
			Map<Integer, Long> hourlySales = getHourlySales();
			Map<String, Long> dayOfWeekSales = getDayOfWeekSales();
			List<Map<String, Object>> topMembers = getTopSpenders(5);

			// 2. 수집 성공 시에만 파일 작성 시작
			try (java.io.OutputStreamWriter osw = new java.io.OutputStreamWriter(
					new java.io.FileOutputStream(fileName), "MS949");
				 java.io.BufferedWriter bw = new java.io.BufferedWriter(osw);
				 java.io.PrintWriter writer = new java.io.PrintWriter(bw)) {
				
				writer.println("--- 카페 키오스크 매출 통계 보고서 ---");
				writer.println("생성일시," + new java.util.Date());
				writer.println("총 누적 매출," + totalSales + "원");
				writer.println();

				writer.println("[일별 매출 추이 (최신 10건)]");
				writer.println("날짜,매출액");
				dailySales.forEach((date, sales) -> writer.println(date + "," + sales));
				writer.println();

				writer.println("[카테고리별 매출 분석]");
				writer.println("카테고리,매출액");
				categorySales.forEach((cat, sales) -> writer.println(cat + "," + sales));
				writer.println();

				writer.println("[메뉴별 판매 순위]");
				writer.println("순위,메뉴 정보");
				for (int i = 0; i < topMenus.size(); i++) {
					writer.println((i + 1) + "위," + topMenus.get(i).trim());
				}
				writer.println();

				writer.println("[시간대별 매출 분석]");
				writer.println("시간,매출액");
				hourlySales.forEach((hour, sales) -> writer.println(hour + "시," + sales));
				writer.println();

				writer.println("[요일별 매출 분석]");
				writer.println("요일,매출액");
				dayOfWeekSales.forEach((day, sales) -> writer.println(day + "," + sales));
				writer.println();

				writer.println("[우수 회원 기여도 분석]");
				writer.println("순위,휴대폰 번호,누적 결제액");
				for (int i = 0; i < topMembers.size(); i++) {
					Map<String, Object> m = topMembers.get(i);
					long total = ((Number) m.get("total")).longValue();
					writer.println((i + 1) + "위," + m.get("phone") + "," + total + "원");
				}

				writer.flush(); // 명시적 플러시
				System.out.println("\n[성공] 매출 보고서가 생성되었습니다: " + fileName);
			}
		} catch (Exception e) {
			// 상세 에러 로그 출력 (데이터가 너무 많아 쿼리 타임아웃 발생 시 확인 가능)
			e.printStackTrace();
			throw new exception.InfrastructureException("CSV 내보내기 중 데이터 수집 또는 파일 쓰기 오류: " + e.getMessage(), e);
		}
	}
}

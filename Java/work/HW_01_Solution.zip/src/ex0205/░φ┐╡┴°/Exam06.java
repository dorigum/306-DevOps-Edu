package ex0205.고영진;
/*
 *  작성일: 2026-02-05
 *	작성자: 고영진
 */
public class Exam06 {
	public static void main(String[] args) {
		int[][] array = {
				{95, 86},
				{83, 92, 96},
				{78, 83, 93, 87, 88}
		};
		
		System.out.println(array.length); // 3
		System.out.println(array[2].length); // 5
		
	}
}

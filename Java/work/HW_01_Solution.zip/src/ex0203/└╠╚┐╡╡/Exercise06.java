package ex0203.이효도;

public class Exercise06 {

	public static void main(String[] args) {
		 int lengthTop = 52;
		 int lengthBottm = 3;
		 int height = 7;
		 double area = (lengthTop + lengthBottm)*height/2.0; 
		 System.out.println(area);
	}

}

package ex0203.이효도;

public class Exercise05 {

	public static void main(String[] args) {
		 int value = 420;
		 System.out.println(value/100*100);//300
	}

}

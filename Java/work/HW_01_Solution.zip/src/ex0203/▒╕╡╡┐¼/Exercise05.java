package ex0203.구도연;

public class Exercise05 {

	public static void main(String[] args) {
		// 비교 연산자와 논리 연산자의 복합 연산식
		// 연산식의 출력 결과 도출하기
		int x = 10;
		int y = 5;
		
		System.out.println((x > 7) && (y <= 5)); // true
		System.out.println((x % 3 == 2) || (y % 2 != 1)); // false

	}

}

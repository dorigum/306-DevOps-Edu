package ex0203.구도연;

public class Exercise03 {

	public static void main(String[] args) {
		// 십의 자리 이하를 버리는 코드 작성
		// ex: 변수 value 값이 356이라면 300 출력
		// ※산술 연산자만 사용
		int value = 356;
		System.out.println(value - 56);
	}

}

package ex0203;

public class HelloTest {

	public static void main(String[] args){
		// 모니터 출력
		System.out.println("dd");
		System.out.println("\"곧 밥먹으로\n고고");
		

	}
	
	
	
	

}

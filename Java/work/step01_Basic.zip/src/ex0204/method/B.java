package ex0204.method;

//llegal modifier for the class A; only public, abstract & final are permitted
 /*protected*/ class A{//The public type A must be defined in its own file
	 public static void main(String[] args) {
			System.out.println("메인입니다.1");
		}
}
///////////////////////
public class B {
	public static void main(String[] args) {
		System.out.println("메인입니다.2");
		
	}
}
///////////////////////////////
class C{
	
}
//저장 -> 컴파일    ~.class

